# Laboratorio 1: Analisis de Algoritmos

## Descripcion

- Se trabaja en oarejas

- A medida que se vaya avanzando con la explicación, se encontraran con ejercicios en donde deberia dar solucion 